<?php if (!defined('THINK_PATH')) exit(); /*a:11:{s:36:"template/DYXS2/html/index/index.html";i:1620611088;s:53:"/var/www/html/template/DYXS2/html/public/include.html";i:1622300580;s:50:"/var/www/html/template/DYXS2/html/public/head.html";i:1622203936;s:50:"/var/www/html/template/DYXS2/html/index/slide.html";i:1620636056;s:48:"/var/www/html/template/DYXS2/html/index/hot.html";i:1620619362;s:52:"/var/www/html/template/DYXS2/html/public/vodbox.html";i:1620599430;s:49:"/var/www/html/template/DYXS2/html/index/list.html";i:1620918464;s:50:"/var/www/html/template/DYXS2/html/index/links.html";i:1628435406;s:50:"/var/www/html/template/DYXS2/html/public/foot.html";i:1621897572;s:54:"/var/www/html/template/DYXS2/html/public/tcnotice.html";i:1620611178;s:53:"/var/www/html/template/DYXS2/html/public/website.html";i:1621897662;}*/ ?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <title><?php echo $maccms['site_name']; ?></title>
    <meta name="keywords" content="<?php echo $maccms['site_keywords']; ?>" />
    <meta name="description" content="<?php echo $maccms['site_description']; ?>" />
     <?php $file = 'template/DYXS2/asset/admin/Dyxs2.php'; $newfile = 'application/admin/controller/Dyxs2.php'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $file = 'template/DYXS2/asset/admin/dyxsst.php'; $newfile = 'application/extra/dyxsst.php'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $file = 'template/DYXS2/asset/admin/dycms.html'; $newfile = 'application/admin/view/system/dycms.html'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $dyxsst = file_exists('application/extra/dyxsst.php') ? require('application/extra/dyxsst.php') : require(substr($maccms['path_tpl'], strlen($maccms['path'])).'asset/admin/dyxsst.php'); ?>

<link rel="icon" href="<?php echo mac_url_img($dyxsst['dycms']['s1']['logo2']); ?>" type="image/png" />
<link href="<?php echo $maccms['path_tpl']; ?>static/css/style.css" rel="stylesheet" type="text/css">
<link href="<?php echo $maccms['path_tpl']; ?>static/css/ali.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>static/css/swiper-bundle.min.css" type="text/css">
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.js"></script>
<script src="https://cdn.bootcdn.net/ajax/libs/layer/3.4.0/layer.min.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.lazyload.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.autocomplete.js"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.cookie.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/home.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.clipboard.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/swiper-bundle.min.js"></script>
<?php if($maccms['aid'] == 15): ?>
<script type="text/javascript">var vod_name='<?php echo $obj['vod_name']; ?>',vod_url=window.location.href,vod_part='<?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?>';</script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/history.js"></script>
 <script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.qrcode.min.js"></script>
<?php endif; ?>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/script.js"></script>

</head>
<body class="homepage" >
    
 <header id="header" class="wrapper">
	<div class="nav">
		<h1 class="slogan black"> <?php echo $dyxsst['dycms']['s1']['gg']; ?></h1>
		<div id="index-nav">
			<ul class="nav-menu-items">
				<li class="nav-menu-item <?php if($maccms['aid'] == 1): ?>selected<?php endif; ?>">
					<a href="<?php echo $maccms['path']; ?>" class="black " title="<?php echo $maccms['site_name']; ?>首页"><i class="icon-home"></i>首页</a>
				</li>
				 <?php $__TAG__ = '{"num":"4","order":"asc","by":"sort","ids":"parent","flag":"vod","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>			
				<li class="nav-menu-item <?php if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?>selected<?php endif; ?>">
					<a class="nav-link black" href="<?php echo mac_url_type($vo); ?>">
							<?php if(stristr($vo['type_name'],'纪录片')==true||stristr($vo['parent']['type_name'],'纪录片')==true): ?><i class="iconfont icon-zhibo"></i><?php elseif(stristr($vo['type_name'],'直播')==true||stristr($vo['parent']['type_name'],'直播')==true): ?><i class="iconfont icon-qiepian"></i><?php elseif(stristr($vo['type_name'],'美剧')==true||stristr($vo['parent']['type_name'],'美剧')==true): ?><i class="iconfont icon-qita"></i><?php else: if($vo['type_id'] == 1): ?>
	                        <i class="icon-cate-dy"></i>
	                        <?php elseif($vo['type_id'] == 2): ?>
	                        <i class="icon-cate-ds"></i>
	                        <?php elseif($vo['type_id'] == 4): ?>
	                        <i class="icon-cate-dm"></i>
	                        <?php else: ?>
	                        <i class="icon-cate-zy"></i>
	                        <?php endif; endif; ?>
					<?php echo $vo['type_name']; ?> </a>
				</li>
				<?php endforeach; endif; else: echo "" ;endif; if($dyxsst['dycms']['s2']['diy1'] == 1): ?>
					<li class="nav-menu-item">
					<a href="<?php echo $dyxsst['dycms']['s2']['diy1url']; ?>" class="nav-link black " ><i class="icon-more"></i>&nbsp;<?php echo $dyxsst['dycms']['s2']['diy1name']; ?></a>
				</li>
				<?php endif; if($dyxsst['dycms']['s2']['diy2'] == 1): ?>
					<li class="nav-menu-item">
					<a href="<?php echo $dyxsst['dycms']['s2']['diy2url']; ?>" class="nav-link black " ><i class="icon-more"></i>&nbsp;<?php echo $dyxsst['dycms']['s2']['diy2name']; ?></a>
				</li>
				<?php endif; if($dyxsst['dycms']['s2']['wz'] == 1): ?>
				<li class="nav-menu-item domain black "><i class="icon-domain"></i>网址<em>+</em></li>
				<?php endif; ?>
				<li class="space-line-bold black "></li>
				<li class="nav-menu-item drop">
					<span class="nav-menu-icon">
                        <i class="icon-watch-history  black "></i>
                    </span>
					<div class="drop-content drop-history">
						<div class="drop-content-box">
							<ul class="drop-content-items" id="history">
								<li class="list-item list-item-title">
									<a href="" class="playlist historyclean">
										<i class="icon-clear"></i>
									</a>
									<strong>我的观影记录</strong>
								</li>
							</ul>
						</div>
					</div>
					<div class="shortcuts-mobile-overlay"></div>
				</li>
				<li class="space-line-bold"></li>
				<li class="nav-menu-item drop">
					<span class="nav-menu-icon">
                        <i class="icon-all" style="color: #000;"></i>
                    </span>
					<div class="drop-content sub-block">
						<div class="drop-content-box grid-box">
							<ul class="drop-content-items grid-items">
								<li class="grid-item">
									<a href="<?php echo $maccms['path']; ?>">
										<i class="icon-home"></i>
										<div class="grid-item-name" title="<?php echo $maccms['site_name']; ?>首页">首页</div>
									</a>
								</li>
							 <?php $__TAG__ = '{"order":"asc","by":"sort","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>			
								<li  class="grid-item">
								<a href="<?php echo mac_url_type($vo); ?>" title="<?php echo $vo['type_name']; ?>">
							<?php if(stristr($vo['type_name'],'纪录片')==true||stristr($vo['parent']['type_name'],'纪录片')==true): ?><i class="iconfont icon-zhibo"></i><?php elseif(stristr($vo['type_name'],'直播')==true||stristr($vo['parent']['type_name'],'直播')==true): ?><i class="iconfont icon-qiepian"></i><?php elseif(stristr($vo['type_name'],'美剧')==true||stristr($vo['parent']['type_name'],'美剧')==true): ?><i class="iconfont icon-qita"></i><?php else: ?>
							<i class="<?php switch($vo['type_id']): case "1": ?>icon-cate-dy<?php break; case "2": ?>icon-cate-ds<?php break; case "3": ?>icon-cate-zy<?php break; case "4": ?>icon-cate-dm<?php break; case "5": ?>iconfont icon-zixun<?php break; default: ?>icon-zixun<?php endswitch; ?>"></i><?php endif; ?>
									<div class="grid-item-name"><?php echo $vo['type_name']; ?></div>
									</a>
								</li>
								<?php endforeach; endif; else: echo "" ;endif; if($dyxsst['dycms']['s2']['wz'] == 1): ?>
								<li class="grid-item">
								<a href="<?php echo mac_url('label/web'); ?>"><i class="icon-domain"></i>
								<div class="grid-item-name" title="网址">网址</div>
								</a>
								</li>
								<?php endif; if($dyxsst['dycms']['s2']['topic'] == 1): ?>
								<li class="grid-item">
								<a href="<?php echo mac_url('topic/index'); ?>"><i class="iconfont icon-zhuanxiangxinxi"></i>
								<div class="grid-item-name" title="专题">专题</div>
								</a>
								</li>
								<?php endif; if($dyxsst['dycms']['s2']['diy1'] == 1): ?>
								<li class="grid-item">
								<a href="<?php echo $dyxsst['dycms']['s2']['diy1url']; ?>"><i class="icon-more"></i>
								<div class="grid-item-name" title="<?php echo $dyxsst['dycms']['s2']['diy1name']; ?>"><?php echo $dyxsst['dycms']['s2']['diy1name']; ?></div>
								</a>
								</li>
								<?php endif; if($dyxsst['dycms']['s2']['diy2'] == 1): ?>
								<li class="grid-item">
								<a href="<?php echo $dyxsst['dycms']['s2']['diy2url']; ?>"><i class="icon-more"></i>
								<div class="grid-item-name" title="<?php echo $dyxsst['dycms']['s2']['diy2name']; ?>"><?php echo $dyxsst['dycms']['s2']['diy2name']; ?></div>
								</a>
								</li>
								<?php endif; ?>								
								<li class="grid-item grid-more">
									<a class="grid-more-link"  href="<?php echo mac_url_type($obj,['id'=>1],'show'); ?>" title="查看全部影片">
										<div class="grid-item-name">全部影片</div>
									</a>
								</li>
								<?php if($dyxsst['dycms']['s2']['app'] == 1): ?>
							    <li class="grid-item grid-more android">
								<a href="<?php echo mac_url('label/app'); ?>" class="grid-more-link" title="下载<?php echo $maccms['site_name']; ?>APP">
								<div class="grid-item-name">下载客户端</div>
								</a>
								</li>
								<?php endif; ?>
							</ul>
						</div>
					</div>
					<div class="shortcuts-mobile-overlay"></div>
				</li>
				<?php if($dyxsst['dycms']['s2']['user'] == 1): ?>				
				<li class="space-line-bold"></li>
				<li class="nav-menu-item drop">
				<?php if($user['group']['group_id'] == 1): ?>
				<a href="<?php echo mac_url('user/login'); ?>" class=" black " title="用户登录"><i class="iconfont icon-yonghu"></i></a>
				<?php else: ?>
				<a href="<?php echo mac_url('user/index'); ?>" class=" black " title="个人中心"><i class="iconfont icon-yonghu"></i></a>				
				</li>
				<?php endif; endif; ?>
			</ul>
		</div>
	</div>
	  <div id="search-content">
	<div class="index-logo"><span class="logo-s"><img src="<?php echo mac_url_img($dyxsst['dycms']['s1']['logo1']); ?>" title="<?php echo $maccms['site_name']; ?>"></span></div>
	<form action="<?php echo mac_url('vod/search'); ?>">
		<div class="search-box">
			<input class="search-input ac_wd" id="txtKeywords" type="text" name="wd" autocomplete="off" placeholder="搜索电影、电视剧、综艺、动漫">
			<div class="search-drop">
				<div class="drop-content-items ac_hot none">
					<div class="list-item list-item-title"><strong>大家都在搜这些影片</strong></div>
					<div class="search-tag">
						<?php $_6627093c496b4=explode(',',$maccms['search_hot']); if(is_array($_6627093c496b4) || $_6627093c496b4 instanceof \think\Collection || $_6627093c496b4 instanceof \think\Paginator): if( count($_6627093c496b4)==0 ) : echo "" ;else: foreach($_6627093c496b4 as $key2=>$vo2): ?>
						<a href="<?php echo mac_url('vod/search',['wd'=>$vo2]); ?>" class="<?php if($key2 < 4): ?>hot <?php else: endif; ?>"><i class="icon-hot"></i><?php echo $vo2; ?></a>
						<?php endforeach; endif; else: echo "" ;endif; ?>
					</div>
				</div>
			</div>
			<button class="search-btn search-go" type="submit"><i class="icon-search"></i></button>
			<button class="cancel-btn" type="button">取消</button>
		</div>
	</form>
</div>
</header>       
	     
<main id="index-main" class="wrapper">
	<div class="content">
	    	<?php if($dyxsst['dycms']['s2']['slide'] == 1): ?>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/swiper-bundle.min.js"></script>
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>static/css/swiper-bundle.min.css" type="text/css">
   <div class="swiper-container" style="margin-bottom: 20px;">
      <div class="swiper-wrapper">
          <?php $__TAG__ = '{"num":"8","type":"all","order":"desc","by":"time","level":"9","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
         <div class="swiper-slide">
        <a class="dymr banner" href="<?php echo mac_url_vod_detail($vo); ?>" style="background: url(<?php echo mac_url_img($vo['vod_pic_slide']); ?>) center no-repeat;  background-size: cover;">
          <div class="txt-info">
            <p class="gate"><span><?php echo $vo['type']['type_name']; ?></span></p>
            <p class="name"><?php echo $vo['vod_name']; ?></p>
            <p class="info"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?> </p>
          </div>
          </a>
        </div>
           	<?php endforeach; endif; else: echo "" ;endif; ?>		  
        			
      </div>
      <!-- 如果需要分页器 -->
      <div class="swiper-pagination"></div>

      <!-- 如果需要导航按钮 -->
      <div class="swiper-button-prev"></div>
      <div class="swiper-button-next"></div>

    </div>
    
     <script>
       var swiper = new Swiper('.swiper-container', {
            //direction: 'vertical', // 垂直切换选项
            direction: 'horizontal',//水平方向
            loop: true, // 循环模式选项

            autoplay: true,//等同于以下设置
            autoplay: {
                delay: 3000,
                stopOnLastSlide: false,
                disableOnInteraction: false,//改为false,点击按钮可以继续动
            },


            // 如果需要分页器
            pagination: {
                el: '.swiper-pagination',
				 clickable: true,
            },

            // 如果需要前进后退按钮
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },

            // 如果需要滚动条
            scrollbar: {
                el: '.swiper-scrollbar',
            },
        })        
        
    </script>
    <?php endif; ?>
<style type="text/css">
.dymr{display: block; position: relative; padding-top: 150%;  background-size: cover;    border-radius: 8px;}
	.dymr.banner{ padding-top: 30%;  }
	@media (max-width:767px){.dymr.banner{ padding-top: 45%;}}
</style>	 

	<!--AD1-->
	<?php if($dyxsst['dycms']['s3']['ad1'] == 1): ?>
	<div class="index-recommend recommend-list"><a href="<?php echo $dyxsst['dycms']['s3']['ad1_url']; ?>" target="_blank"><div class="pc"><img src="<?php echo mac_url_img($dyxsst['dycms']['s3']['ad1_pc']); ?>"></div><div class="phone"><img src="<?php echo mac_url_img($dyxsst['dycms']['s3']['ad1_wap']); ?>"></div></a></div>
	<?php endif; ?>
	<!---->
	    
	     <div class="module">
	<div class="module-heading">
		<h2 class="module-title"><i class="icon-hot" ></i>正在热播</h2>
	</div>
	<div class="module-list module-lines-list">
		<div class="module-items">
			<?php $__TAG__ = '{"num":"16","type":"all","order":"desc","by":"time","level":"8","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
			                 <div class="module-item">
				<div class="module-item-cover">
					<div class="module-item-pic">
						<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>" >
							<i class="icon-play"></i>
						</a>
						<img class="lazy lazyloaded"  data-src="<?php echo mac_url_img($vo['vod_pic']); ?>" src="<?php echo mac_url_img($dyxsst['dycms']['s1']['pic']); ?>"  alt="<?php echo $vo['vod_name']; ?>">
						<div class="loading"></div>
					</div>
					<div class="module-item-caption">
						<span><?php echo $vo['vod_year']; ?></span>
						<span class="video-class"><?php echo $vo['type']['type_name']; ?></span>
						<span><?php echo $vo['vod_area']; ?></span>
					</div>
					<div class="module-item-content">
						<div class="module-item-style video-name">
							<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
						</div>
						<div class="module-item-style video-tag">
						<?php echo mac_url_create(mac_default($vo['vod_actor'],'未知'),'actor'); ?>
						</div>
						<div class="module-item-style video-text"><?php echo $vo['vod_blurb']; ?></div>
					</div>
				</div>
				<div class="module-item-titlebox">
					<a href="<?php echo mac_url_vod_detail($vo); ?>" class="module-item-title" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
				</div>
				<div class="module-item-text"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></div>
			</div>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		</div>
	</div>
</div>	 
	     
	     		<!-- Module End -->
		<div class="module">
			<div class="module-heading">
				<h2 class="module-title"><i class="icon-happy"></i> 最新影片</h2>
				<div class="module-tab">
					<label class="module-tab-name">
						<span class="module-tab-value">全部</span>
						<i class="icon-arrow-bottom"></i>
					</label>
					<div class="module-tab-items">
						<div class="module-tab-title">
							选择类型
							<span class="close-drop">
								<i class="icon-close-o"></i>
							</span>
						</div>
						<div>
							<span class="module-tab-item tab-item selected" data-id="0" data-name="全部">全部</span>
							<?php $__TAG__ = '{"order":"asc","by":"sort","mid":"1","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
							<span class="module-tab-item tab-item" data-id="<?php echo $vo['type_id']; ?>" data-name="<?php echo $vo['type_name']; ?>"><?php echo $vo['type_name']; ?></span>
							<?php endforeach; endif; else: echo "" ;endif; ?>
						</div>
					</div>
				</div>
				<div class="shortcuts-mobile-overlay"></div>
			</div>
			
			<div class="module-list module-line-list tab-list selected" id="tab-list-0">
				<div class="module-items scroll-box">
					<div class="scroll-content">
	                    <?php $__TAG__ = '{"num":"16","type":"all","order":"desc","by":"time","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
	                    	                <div class="module-item">
				<div class="module-item-cover">
					<div class="module-item-pic">
						<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>" >
							<i class="icon-play"></i>
						</a>
						<img class="lazy lazyloaded"  data-src="<?php echo mac_url_img($vo['vod_pic']); ?>" src="<?php echo mac_url_img($dyxsst['dycms']['s1']['pic']); ?>"  alt="<?php echo $vo['vod_name']; ?>">
						<div class="loading"></div>
					</div>
					<div class="module-item-caption">
						<span><?php echo $vo['vod_year']; ?></span>
						<span class="video-class"><?php echo $vo['type']['type_name']; ?></span>
						<span><?php echo $vo['vod_area']; ?></span>
					</div>
					<div class="module-item-content">
						<div class="module-item-style video-name">
							<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
						</div>
						<div class="module-item-style video-tag">
						<?php echo mac_url_create(mac_default($vo['vod_actor'],'未知'),'actor'); ?>
						</div>
						<div class="module-item-style video-text"><?php echo $vo['vod_blurb']; ?></div>
					</div>
				</div>
				<div class="module-item-titlebox">
					<a href="<?php echo mac_url_vod_detail($vo); ?>" class="module-item-title" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
				</div>
				<div class="module-item-text"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></div>
			</div>
	                    <?php endforeach; endif; else: echo "" ;endif; ?>
					</div>
				</div>
			</div>
			
			<?php $__TAG__ = '{"order":"asc","by":"sort","mid":"1","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
			<div class="module-list module-line-list tab-list" id="tab-list-<?php echo $vo['type_id']; ?>">
				<div class="module-items scroll-box">
					<div class="scroll-content">
	                    <?php $__TAG__ = '{"num":"16","type":"'.$vo['type_id'].'","order":"desc","by":"time","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
	                    	                <div class="module-item">
				<div class="module-item-cover">
					<div class="module-item-pic">
						<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>" >
							<i class="icon-play"></i>
						</a>
						<img class="lazy lazyloaded"  data-src="<?php echo mac_url_img($vo['vod_pic']); ?>" src="<?php echo mac_url_img($dyxsst['dycms']['s1']['pic']); ?>"  alt="<?php echo $vo['vod_name']; ?>">
						<div class="loading"></div>
					</div>
					<div class="module-item-caption">
						<span><?php echo $vo['vod_year']; ?></span>
						<span class="video-class"><?php echo $vo['type']['type_name']; ?></span>
						<span><?php echo $vo['vod_area']; ?></span>
					</div>
					<div class="module-item-content">
						<div class="module-item-style video-name">
							<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
						</div>
						<div class="module-item-style video-tag">
						<?php echo mac_url_create(mac_default($vo['vod_actor'],'未知'),'actor'); ?>
						</div>
						<div class="module-item-style video-text"><?php echo $vo['vod_blurb']; ?></div>
					</div>
				</div>
				<div class="module-item-titlebox">
					<a href="<?php echo mac_url_vod_detail($vo); ?>" class="module-item-title" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
				</div>
				<div class="module-item-text"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></div>
			</div>
	                    <?php endforeach; endif; else: echo "" ;endif; ?>
					</div>
				</div>
			</div>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		</div>
<?php $__TAG__ = '{"order":"asc","by":"sort","ids":"parent","id":"vo1","key":"key1","flag":"vod"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key1 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo1): $mod = ($key1 % 2 );++$key1;?>				
<div class="module">
	<div class="module-heading">
		<h2 class="module-title">
				<?php if($vo['type_id'] == 4): ?>
	            <i class="icon-cate-dy"></i>
	            <?php elseif($vo['type_id'] == 1): ?>
	            <i class="icon-cate-ds"></i>
	            <?php elseif($vo['type_id'] == 3): ?>
	            <i class="icon-cate-dm"></i>
	            <?php else: ?>
	            <i class="icon-cate-zy"></i>
	            <?php endif; ?> 		    
		    <?php echo $vo1['type_name']; ?></h2>
		<a class="more" href="<?php echo mac_url_type($vo1,[],'type'); ?>" title="更多<?php echo $vo1['type_name']; ?>">更多<?php echo $vo1['type_name']; ?>
		<i class="icon-arrow-right-o"></i>
		</a>
	</div>
	<div class="module-list module-lines-list">
		<div class="module-items">
	    <?php $__TAG__ = '{"num":"16","type":"'.$vo1['type_id'].'","order":"desc","by":"time","year":"","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>  
	                    <div class="module-item">
				<div class="module-item-cover">
					<div class="module-item-pic">
						<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>" >
							<i class="icon-play"></i>
						</a>
						<img class="lazy lazyloaded"  data-src="<?php echo mac_url_img($vo['vod_pic']); ?>" src="<?php echo mac_url_img($dyxsst['dycms']['s1']['pic']); ?>"  alt="<?php echo $vo['vod_name']; ?>">
						<div class="loading"></div>
					</div>
					<div class="module-item-caption">
						<span><?php echo $vo['vod_year']; ?></span>
						<span class="video-class"><?php echo $vo['type']['type_name']; ?></span>
						<span><?php echo $vo['vod_area']; ?></span>
					</div>
					<div class="module-item-content">
						<div class="module-item-style video-name">
							<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
						</div>
						<div class="module-item-style video-tag">
						<?php echo mac_url_create(mac_default($vo['vod_actor'],'未知'),'actor'); ?>
						</div>
						<div class="module-item-style video-text"><?php echo $vo['vod_blurb']; ?></div>
					</div>
				</div>
				<div class="module-item-titlebox">
					<a href="<?php echo mac_url_vod_detail($vo); ?>" class="module-item-title" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
				</div>
				<div class="module-item-text"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></div>
			</div>
		<?php endforeach; endif; else: echo "" ;endif; ?>
		</div>
	</div>
</div>
 <?php endforeach; endif; else: echo "" ;endif; ?> 
	     
	</div>
</main>
         <div id="friendlink" class="wrapper hidden-xs">
	<div class="content">
		<h2>友情链接：</h2>
		<a href="https://www.at008.cn" target="_blank" title="苹果cms模板">苹果cms模板</a>
		<?php $__TAG__ = '{"num":"99","type":"font","id":"vo","key":"key"}';$__LIST__ = model("Link")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
		<a href="<?php echo $vo['link_url']; ?>" target="_blank" title="<?php echo $vo['link_name']; ?>"><?php echo $vo['link_name']; ?></a>
        <?php endforeach; endif; else: echo "" ;endif; ?>
	</div>
</div> 

         <footer id="footer" class="wrapper">
	<p class="sitemap">
	    <?php if($dyxsst['dycms']['s2']['about'] == 1): ?>
		<a target="_blank" href="<?php echo mac_url('label/about'); ?>">关于</a><span class="space-line-bold"></span>
		<?php endif; ?>
		<a target="_blank" href="<?php echo mac_url('map/index'); ?>">MAP</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/index'); ?>">RSS</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/baidu'); ?>">Baidu</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/baidu'); ?>">Google</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/bing'); ?>">Bing</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/so'); ?>">so</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/sogou'); ?>">Sogou</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/sm'); ?>">SM</a>
	</p>
	<p><?php echo $dyxsst['dycms']['s1']['sm']; ?></p>
	<p class="none"><?php echo $maccms['site_tj']; ?></p>
</footer>



<div class="foot_right_bar">
	<div title="求片留言">
	<a  href="<?php echo mac_url('gbook/index'); ?>" >
	<i class="iconfont icon-liuyan"></i>
	</a>
	</div>
	<div class="goTop" title="返回顶部">
		<i class="iconfont icon-up"></i>
	</div>
</div>

<script type="text/javascript">
$(function(){	
	$(window).scroll(function() {		
		if($(window).scrollTop() >= 100){
			$('.goTop').fadeIn(300); 
		}else{    
			$('.goTop').fadeOut(300);    
		}  
	});
	$('.goTop').click(function(){
	$('html,body').animate({scrollTop: '0px'}, 800);});	
});
</script>

<?php if($dyxsst['dycms']['s2']['tc'] == 1): ?>

<div class="popup" id="note" style="display:none;">
	<div class="popup-icon"><img src="<?php echo $maccms['path_tpl']; ?>static/picture/backhome.svg"></div>
	<div class="popup-header">
		<h3 class="popup-title">公告内容</h3>
	</div>
	<div class="popup-main">
<?php echo $dyxsst['dycms']['s2']['tc_noti']; ?>
	</div>
	<div class="popup-footer"><span class="popup-btn" onclick="closeclick()">我记住啦</span></div>
</div>
<?php endif; ?>
<script src="<?php echo $maccms['path_tpl']; ?>static/js/tccookie.js"></script>
 <!-- 弹窗公告-->

   
<div class="popup popup-notice none">
	<div class="popup-icon"><img src="<?php echo $maccms['path_tpl']; ?>static/picture/backhome.svg"></div>
	<div class="popup-header">
		<h3 class="popup-title">域名列表</h3></div>
	<div class="popup-main">
		<p>本站有多个域名方便大家记住可以上哦!</p>
		<p>-
			<a><strong><?php echo $maccms['site_url']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web1']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web2']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web3']; ?></strong></a><br>
		</p>
	</div>
	<div class="popup-footer">
		<a href="<?php echo mac_url('label/web'); ?>" class="popup-btn-o">查看全部域名</a>
		<?php if($dyxsst['dycms']['s2']['about'] == 1): ?>
		<a href="<?php echo mac_url('label/about'); ?>" class="popup-btn-o">关于本站</a>
		<?php endif; ?>
	</div>
	<div class="close-popup" id="close-popup"><i class="icon-close-o"></i></div>
</div> <!-- 网址-->
         
<div class="shortcuts-mobile-overlay"></div>
 
</body>
</html>
